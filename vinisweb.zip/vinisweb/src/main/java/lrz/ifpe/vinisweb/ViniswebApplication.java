package lrz.ifpe.vinisweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViniswebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViniswebApplication.class, args);
	}

}
