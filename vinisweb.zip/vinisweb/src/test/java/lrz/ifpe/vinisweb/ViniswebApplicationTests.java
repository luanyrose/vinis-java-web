package lrz.ifpe.vinisweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViniswebApplicationTests {

	@Test
	void contextLoads() {
	}

}
